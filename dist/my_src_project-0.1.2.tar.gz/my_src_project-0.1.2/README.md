# My Project

A simple Python package.

## Installation

```bash
pip install my_src_project
