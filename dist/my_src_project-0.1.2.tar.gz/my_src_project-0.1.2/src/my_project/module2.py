#!/usr/bin/python3
# _*_ coding: utf-8 _*_
#
# Copyright (C) 2025 - 2025 Guanhao Sun, Inc. All Rights Reserved 
#
# @Time    : 2025/1/15 9:52
# @Author  : Guanhao Sun
# @File    : module2.py
# @IDE     : PyCharm

def greet(name):
    return f"Hello, {name}!"
