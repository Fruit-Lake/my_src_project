#!/usr/bin/python3
# _*_ coding: utf-8 _*_
#
# Copyright (C) 2025 - 2025 Guanhao Sun, Inc. All Rights Reserved 
#
# @Time    : 2025/1/15 9:51
# @Author  : Guanhao Sun
# @File    : __init__.py
# @IDE     : PyCharm

__version__ = "0.1.2"